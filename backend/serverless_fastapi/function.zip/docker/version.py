version = "5.0.3"
version_info = tuple(int(d) for d in version.split("-")[0].split("."))
